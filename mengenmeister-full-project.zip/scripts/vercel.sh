#!/bin/bash

echo "Running custom Vercel build..."
npm run build