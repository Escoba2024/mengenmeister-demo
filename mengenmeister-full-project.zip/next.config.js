module.exports = {
  env: {
    OPENAI_API_KEY: process.env.OPENAI_API_KEY,
    MENGENMEISTER_API_URL: process.env.MENGENMEISTER_API_URL
  }
}