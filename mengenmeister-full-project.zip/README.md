# MengenMeister Demo – Vollständiges Projekt

1. `npm install`
2. `npm run dev`
3. Verknüpfen mit Vercel
